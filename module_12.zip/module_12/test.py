import psycopg2

conn = psycopg2.connect("dbname=test user=shantanu")
print('Connected Successfully')

cursor = conn.cursor()
    

def table():
    global cursor
    cursor.execute('''drop table if exists employees; create table employees(Name Text, ID int, Age int);''')

def data():
    global cursor

    name=input('Enter name: ')
    id=input('Enter id: ')
    age=input('Enter age: ')

    cursor.execute('''insert into employees(Name, Id, Age) values(%s,%s,%s)''', (name, id, age))

def extract():
    global cursor
    cursor.execute('''select * from employees''')
    print(cursor.fetchmany(10))

table()
data()
data()
extract()

conn.commit()

conn.close();
